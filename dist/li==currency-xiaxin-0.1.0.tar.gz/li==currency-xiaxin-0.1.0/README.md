Try to build a library contains ten classes in Max'code
